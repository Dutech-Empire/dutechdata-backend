export const DATA_BUNDLES = {
  mini: { mb: 100, price: 100 },
  basic: { mb: 250, price: 200 },
  study: { mb: 500, price: 350 },
  dayplus: { mb: 1000, price: 600 },
};
