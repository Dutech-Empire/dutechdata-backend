export const BORROW_RULES = {
  BORROW_MB: 50,
};
