export const EARN_RULES = {
  EARN_MB: 20,        // MB per earn action
  DAILY_CAP_MB: 100,  // max MB per day
};
